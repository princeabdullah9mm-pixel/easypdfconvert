Easy PDF Converter - starter website

1. Open index.html to test the website.
2. For free hosting, upload index.html to a GitHub repository and enable GitHub Pages.
3. Later, buy a custom domain and connect it to the hosting.
4. Replace the canonical URL placeholder in index.html with the real domain.
5. Add separate SEO pages for each tool and create sitemap.xml + robots.txt.

This starter currently includes:
- PDF to JPG (first page)
- JPG/PNG to PDF
- Merge PDF
- Split PDF (first page)

It is a starter, not the final production version. More tools can be added next.
